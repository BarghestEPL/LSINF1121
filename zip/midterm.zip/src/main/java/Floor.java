public class Floor {
    /**
     * @param node La racine d'un arbre 2-3
     * @param x
     * @return La valeur la plus proche possible de x (y compris x lui-meme) contenue dans l'arbre et plus petite que x.
     *         si une telle valeur n'existe pas, null.
     * @throws Exception
     */
    public static Integer floor(TwoThreeNode node, int x) throws Exception {
        // TODO
        return null;
    }
}
