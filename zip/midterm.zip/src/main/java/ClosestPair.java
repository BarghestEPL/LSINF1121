import java.util.Arrays;

public class ClosestPair {

    /**
     *
     * @param input a non empty array
     * @return an array containing two values a,b present in the input array (possibly the same value)
     *         such that |x-(a+b)| is minimum
     *
     */
    public static int[] closestPair(int [] input, int x) {
        // TODO
        return null;
    }

}
